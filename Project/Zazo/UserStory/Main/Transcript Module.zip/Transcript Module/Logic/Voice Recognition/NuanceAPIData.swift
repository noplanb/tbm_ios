//
//  NuanceAPIData.swift
//  Zazo
//
//  Created by Rinat Gabdullin on 27/06/16.
//  Copyright © 2016 No Plan B. All rights reserved.
//

import Foundation

struct NuanceAPIData {
    let appKey: String
    let appId: String
    let asrKey: String
    
    static let sandboxData = NuanceAPIData(appKey: "e764126225d030f4e415190d98de053913538ea5f5ad0f037699217d9b704682d458e5fa2815ee0c2a0719c2e51ffcf8728a9d6837ac6bad468c2ae1fc7064d0",
                                           appId: "NMDPTRIAL_elfishawy_sani_gmail_com20151016074206",
                                           asrKey: "C4461956B60BZAZO")

}