//
//  NativeRecognitionOperation.swift
//  Zazo
//
//  Created by Rinat Gabdullin on 27/06/16.
//  Copyright © 2016 No Plan B. All rights reserved.
//

import Foundation

class NativeRecognitionOperation: RecognitionOperation {
    
}